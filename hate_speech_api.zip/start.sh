#!/bin/bash
uvicorn app:app --host 0.0.0.0 --port 10000
